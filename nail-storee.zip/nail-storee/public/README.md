# Purple Nail Store

Welcome to the **Purple Nail Store**! This e-commerce site allows users to browse and purchase premium nail products.

## Features:
- **User Authentication**: Users can register and log in. The logged-in username is displayed in the header.
- **Product Listing**: Browse a variety of nail products with dynamic rendering.
- **Cart Management**: Add products to the cart, view items, and see the total cost.
- **Shipping Options**: Select between Standard and Express shipping, with costs included in the total.
- **Help Feature**: Click "Help" on the Cart page to learn about shipping options.

## Our vision:
- We sell quality nail products that can help you kick start your nail technitian journey, you are also able to restock on your favourite products from the comfort of your salon.

Enjoy shopping at the **Purple Nail Store**!
